import logging
import pandas as pd
from zenml import step
import os

class IngestData:
    """
    Data ingestion class which ingests data from the source and returns a DataFrame.
    """

    def __init__(self, file_path) -> None:
        """Initialize the data ingestion class."""
        if '.csv' in file_path:
            self.data = pd.read_csv(file_path)
        elif '.xlsx' in file_path:
            self.data = pd.read_excel(file_path)
        else:
            logging.error('Unsupported Data file type, only .csv and .xlsx is supported...')

    def get_data(self) -> pd.DataFrame:
        return self.data


@step
def ingest_data(file_path=f"./data/{os.listdir('./data')[0]}") -> pd.DataFrame:
    """
    Args:
        file_path: str
    Returns:
        df: pd.DataFrame
    """
    try:
        ingest_data = IngestData(file_path)
        data = ingest_data.get_data()
        return data
    except Exception as e:
        logging.error(e)
        raise e