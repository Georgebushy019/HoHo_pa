import streamlit as st
import pandas as pd
import numpy as np
import json
import pickle
import os
import time
from run_deployment import run_pipeline, DEPLOY
from background import BackgroundCSSGenerator
from pipelines.deployment_pipeline import prediction_service_loader

st.set_page_config(layout="wide", page_title="Weather Prediction App", page_icon="🌦️")

img1_path = r"Main background.jpg"
img2_path = r"side Background.jpg"
background_generator = BackgroundCSSGenerator(img1_path, img2_path)
page_bg_img = background_generator.generate_background_css()
st.markdown(page_bg_img, unsafe_allow_html=True)

# Project description
st.sidebar.title("🌦️ Project Description:")
# st.sidebar.divider()
st.sidebar.subheader("📗 Overview:")
st.sidebar.write("This simple project focuses on weather prediction using maximum and minimum temperature, precipitation, and windspeed.")
# st.sidebar.divider()
# MLflow and ZenML integration
st.sidebar.write("## ⛩️ ZenML and 💨 MLflow Integration:")
st.sidebar.write("- Initial model deployed in MLflow local server.")
st.sidebar.write("- ZenML used for building pipelines.")
st.sidebar.write("- Enables end-to-end orchestration and tracking of ML experiments.")
# st.sidebar.divider()
# Model retraining
st.sidebar.write("## 🔄 Model Retraining:")
st.sidebar.write("- Added functionality to retrain the model based on user response.")
st.sidebar.write("- Retrained model can be redeployed seamlessly.")
st.sidebar.write("- Facilitates continuous improvement and adaptation of the model.")
# st.sidebar.divider()

model_path = "random_forest_model.pkl"

with open(model_path, 'rb') as file:
    model = pickle.load(file)

def add_data_to_csv(data):
    data_path = r"/home/prithvi/Desktop/Weather_MLops/data/Weather_data.csv"
    if os.path.exists(data_path):
        data.to_csv(data_path, mode='a', header=False, index=False)

st.title("🌦️ Weather Prediction with Continuous Learning 🤖")
st.divider()
st.subheader("An MLOps Approach with :violet-background[ZenML]⛩️ and :blue-background[MLflow]🌬")
st.write(f"**This app leverages Machine Learning Operations (MLOps) to provide an interactive weather prediction experience with continuous learning capabilities.**")

@st.experimental_fragment
def Input_from_User():
    precipitation = st.number_input("Precipitation (mm) 💧")
    Maximum_Temp = st.number_input("Maximum Temperature (°C) 🌡️")
    Minimum_Temp = st.number_input("Minimum Temperature (°C) 🌡️")
    Wind_Speed = st.number_input("Wind Speed (m/s) 💨")

    return precipitation, Maximum_Temp, Minimum_Temp, Wind_Speed

precipitation, Maximum_Temp, Minimum_Temp, Wind_Speed = Input_from_User()

# Initialize session state for first prediction
if 'first_prediction' not in st.session_state:
    st.session_state['first_prediction'] = True

if st.button("Predict"):
    # Create a DataFrame for the input features
    df = pd.DataFrame(
        {"precipitation": [precipitation],
         "temp_max": [Maximum_Temp],
         "temp_min": [Minimum_Temp],
         "wind": [Wind_Speed]},
    )

    # Convert the DataFrame to a numpy array
    json_list = json.loads(json.dumps(list(df.T.to_dict().values())))
    data = np.array(json_list)

    # Map the prediction to the corresponding weather condition
    weather_mapping_reverse = {
        0: 'sun ☀️',
        1: 'rain 🌧️',
        2: 'drizzle 🌦️',
        3: 'fog 🌫️',
        4: 'snow ❄️'
    }

    if st.session_state['first_prediction']:
        data = df.to_numpy()
        prediction = model.predict(data)
        st.session_state['first_prediction'] = False
    else:
        service = prediction_service_loader(
            pipeline_name="continuous_deployment_pipeline",
            pipeline_step_name="mlflow_model_deployer_step",
            running=False,
        )

        if service is None:
            st.warning("No service could be found. The pipeline will be run first to create a service.")
        else:
            prediction = service.predict(data)

    predicted_weather = weather_mapping_reverse[prediction[0]]

    # Display the prediction
    st.markdown(f"**:green-background[The predicted weather condition for the given parameters is   :<span style='font-size: 2.5em;'>   {predicted_weather}</span>]**", unsafe_allow_html=True)

    st.warning("**Note:** If the predicted weather is incorrect, please retrain the model with the accurate data.")

if 'add_data' not in st.session_state:
    st.session_state['add_data'] = False

if not st.session_state['add_data']:
    st.divider()
    st.subheader("Model Retraining and Redeployment:")
    st.warning("This section simulates MLOps feedback loop. If the prediction is wrong, you can provide the correct weather data to improve the model.")
    Add_data = st.button("Predicted Weather is Wrong")
    if Add_data:
        st.session_state['add_data'] = True

else:
    st.divider()
    Weather = st.selectbox("Select Correct Weather", ['☀️ sun', '🌧️ rain', '🌦️ drizzle', '🌫️ fog', '❄️ snow'])

    if Weather:
        st.write("### Correct Data for Model Improvement:")
        st.write(f"- **Precipitation:** {precipitation}")
        st.write(f"- **Maximum Temperature:** {Maximum_Temp}")
        st.write(f"- **Minimum Temperature:** {Minimum_Temp}")
        st.write(f"- **Wind Speed:** {Wind_Speed}")
        st.write(f"- **:red-background[Weather]:** {Weather}")
        confirm = st.button("Confirm")

        if confirm:
            new_data = pd.DataFrame({
                "precipitation": [precipitation],
                "temp_max": [Maximum_Temp],
                "temp_min": [Minimum_Temp],
                "wind": [Wind_Speed],
                "weather":  [Weather.split()[1]],
            })
            add_data_to_csv(new_data)
            success_message = st.success("Model Training and Redeployment has started. Please be patient until it is over.")
            run_pipeline(config=DEPLOY, min_accuracy=0.01)
            time.sleep(5)
            with st.spinner("Data Ingestion..."):
                st.toast(f"**Do you know?** MLOps automates the entire ML lifecycle, from data prep to model deployment and monitoring.", icon='🤔')
                time.sleep(7)
            with st.spinner("Data Cleaning..."):
                st.toast(f"**Do you know?** MLOps practices improve collaboration between data scientists, data engineers, and operations teams.", icon='👨‍🏫')
                time.sleep(6)
            with st.spinner("Preprocessing..."):
                st.toast(f"**Do you know?** Continuous integration and continuous deployment (CI/CD) principles are key components of MLOps pipelines.", icon='📗')
                time.sleep(8)
            with st.spinner("Model Training..."):
                st.toast(f"**Do you know?** MLOps helps ensure reproducibility and scalability of machine learning models in production environments. ", icon='🔬')
                time.sleep(10)
            with st.spinner("Model Deployment..."):
                st.toast("**Do you know?** MLOps integrates with DevOps practices for seamless deployment!", icon='🛠️')
                time.sleep(5)
            success_message.empty()
            st.balloons()
            st.success("Model Deployment is completed! Please rerun the app for the effects to take place.")
            st.session_state['add_data'] = False
            st.button("Rerun")
