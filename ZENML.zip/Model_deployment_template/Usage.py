# import streamlit as st
# import pandas as pd
# import numpy as np
# import json
# import os
# from run_deployment import run_pipeline, DEPLOY
# from pipelines.deployment_pipeline import prediction_service_loader

# def add_data_to_csv(data):
#     data_path = r"/home/prithvi/Desktop/Model Deployment/data/fault_sequence_data.csv"
#     if os.path.exists(data_path):
#         data.to_csv(data_path, mode='a', header=False, index=False)

# @st.fragment
# def Input_from_User():
#     I1 = st.number_input("Positive Sequence Component (Kv)")
#     I2 = st.number_input("Negative Sequence Component (Kv)")
#     I0 = st.number_input("Zero Sequence Component (Kv)")

#     return I1,I2,I0

# I1,I2,I0 = Input_from_User()

# if st.button("Predict"):
#     # Create a DataFrame for the input features
#     df = pd.DataFrame(
#         {"I1": [I1],
#          "I2": [I2],
#          "I0": [I0]
#         })

#     # Convert the DataFrame to a numpy array
#     json_list = json.loads(json.dumps(list(df.T.to_dict().values())))
#     data = np.array(json_list)

#     # Map the prediction to the corresponding weather condition
#     mapping_reverse = {
#                  0 : 'Nominal',
#                  1 : 'SLG',
#                  2 : 'LLG',
#                  3 : 'LLLG',
#                  4 : 'LL',
#                  5 : 'LLL',
#                  6 : 'Open_Conductor'
#             }
    
#     service = prediction_service_loader(
#             pipeline_name="continuous_deployment_pipeline",
#             pipeline_step_name="mlflow_model_deployer_step",
#             running=False,
#         )

#     if service is None:
#         st.warning("No service could be found. The pipeline will be run first to create a service.")
#     else:
#         prediction = service.predict(data)

#     predicted_class = mapping_reverse[prediction[0]]
#     print(prediction)

#     # Display the prediction
#     st.markdown(f"**:green-background[The predicted Fault Class is :<span style='font-size: 2.5em;'>   {predicted_class}</span>]**", unsafe_allow_html=True)

# if 'add_data' not in st.session_state:
#     st.session_state['add_data'] = False

# if not st.session_state['add_data']:
#     st.divider()
#     st.subheader("Model Retraining and Redeployment:")
#     st.warning("This section simulates MLOps feedback loop. If the prediction is wrong, you can provide the correct Fault data to improve the model.")
#     Add_data = st.button("Predicted Fault Class is Wrong")
#     if Add_data:
#         st.session_state['add_data'] = True

# else:
#     st.divider()
#     Fault = st.selectbox("Select Correct Fault Class", ['SLG', 'LLG', 'LLLG', 'LL', 'LLL','Open_Conductor','Nominal'])

#     if Fault:
#         st.write("### Correct Data for Model Improvement:")
#         st.write(f"- **I1:** {I1}")
#         st.write(f"- **I2:** {I2}")
#         st.write(f"- **I0:** {I0}")
#         st.write(f"- **:red-background[Fault Class]:** {Fault}")
#         confirm = st.button("Confirm")

#         if confirm:
#             new_data = pd.DataFrame({
#                 "I1": [I1],
#                 "I2": [I2],
#                 "I0": [I0],
#                 "Fault_Type":  [Fault],
#             })
#             add_data_to_csv(new_data)
#             success_message = st.success("Model Training and Redeployment has started. Please be patient until it is over.")
#             run_pipeline(config=DEPLOY, min_accuracy=0.01)
#             success_message.empty()
#             st.balloons()
#             st.success("Model Deployment is completed! Please rerun the app for the effects to take place.")
#             st.session_state['add_data'] = False
#             st.button("Rerun")
import streamlit as st
import pandas as pd
import numpy as np
import json
import os
from run_deployment import run_pipeline, DEPLOY , DEPLOY_AND_PREDICT
from pipelines.deployment_pipeline import prediction_service_loader

def add_data_to_csv(data):
    """Append new fault data to CSV for retraining purposes."""
    data_path = r"/home/prithvi/Desktop/Model Deployment/data/fault_sequence_data.csv"
    if os.path.exists(data_path):
        data.to_csv(data_path, mode='a', header=False, index=False)

def Input_from_User():
    """Input form to capture fault sequence data from the user."""
    I1 = st.number_input("Positive Sequence Component (Kv)")
    I2 = st.number_input("Negative Sequence Component (Kv)")
    I0 = st.number_input("Zero Sequence Component (Kv)")
    return I1, I2, I0

# Get inputs from the user
I1, I2, I0 = Input_from_User()

# Prediction section
if st.button("Predict"):
    # Prepare the data in a DataFrame
    df = pd.DataFrame({
        "I1": [I1],
        "I2": [I2],
        "I0": [I0]
    })

    # Convert to JSON format to be used by the model
    json_list = json.loads(json.dumps(list(df.T.to_dict().values())))
    data = np.array(json_list)

    # Mapping fault class labels
    mapping_reverse = {
        0: 'Nominal',
        1: 'SLG',
        2: 'LLG',
        3: 'LLLG',
        4: 'LL',
        5: 'LLL',
        6: 'Open_Conductor'
    }

    # Load the prediction service
    service = prediction_service_loader(
        pipeline_name="continuous_deployment_pipeline",
        pipeline_step_name="mlflow_model_deployer_step",
        running=False,
    )

    # Check if the service is running, otherwise deploy the model
    if service is None or not service.is_running:
        st.warning("No service could be found or the service is not running. Deploying the model.")
        run_pipeline(config=DEPLOY, min_accuracy=0.01)
        st.success("Model deployed! Please rerun the app for predictions.")
    else:
        prediction = service.predict(data)
        predicted_class = mapping_reverse[prediction[0]]
        st.markdown(f"**:green[The predicted Fault Class is : <span style='font-size: 2.5em;'> {predicted_class}</span>]**", unsafe_allow_html=True)

# Retraining and redeployment section
if 'add_data' not in st.session_state:
    st.session_state['add_data'] = False

if not st.session_state['add_data']:
    st.divider()
    st.subheader("Model Retraining and Redeployment:")
    st.warning("If the prediction is incorrect, provide the correct data to improve the model.")
    Add_data = st.button("Predicted Fault Class is Wrong")
    if Add_data:
        st.session_state['add_data'] = True
else:
    st.divider()
    Fault = st.selectbox("Select Correct Fault Class", ['SLG', 'LLG', 'LLLG', 'LL', 'LLL', 'Open_Conductor', 'Nominal'])

    if Fault:
        st.write("### Correct Data for Model Improvement:")
        st.write(f"- **I1:** {I1}")
        st.write(f"- **I2:** {I2}")
        st.write(f"- **I0:** {I0}")
        st.write(f"- **Fault Class:** {Fault}")
        confirm = st.button("Confirm")

        if confirm:
            # Add new data for retraining
            new_data = pd.DataFrame({
                "I1": [I1],
                "I2": [I2],
                "I0": [I0],
                "Fault_Type": [Fault],
            })
            add_data_to_csv(new_data)
            success_message = st.success("Model Training and Redeployment has started. Please be patient.")
            run_pipeline(config=DEPLOY_AND_PREDICT, min_accuracy=0.01)
            success_message.empty()
            st.balloons()
            st.success("Model Deployment is completed! Please rerun the app for the effects to take place.")
            st.session_state['add_data'] = False
            st.button("Rerun")
